import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthProvider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { BookOpen, Users, LogOut, Calendar } from 'lucide-react';
import GradeManagement from '@/components/teacher/GradeManagement';
import SubjectClasses from '@/components/teacher/SubjectClasses';

const TeacherDashboard = () => {
  const { signOut, user } = useAuth();
  const [teacherData, setTeacherData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    subjects: 0,
    students: 0,
    classes: 0,
  });

  useEffect(() => {
    if (user) {
      loadTeacherData();
    }
  }, [user]);

  const loadTeacherData = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    try {
      const { data: teacher } = await supabase
        .from('teachers')
        .select('*, profiles(full_name)')
        .eq('user_id', user.id)
        .single();

      if (teacher) {
        setTeacherData(teacher);

        // Get assigned subjects
        const { data: subjects } = await supabase
          .from('teacher_subjects')
          .select('*')
          .eq('teacher_id', teacher.id);

        setStats({
          subjects: subjects?.length || 0,
          students: 0, // Will be calculated based on classes
          classes: new Set(subjects?.map((s) => s.class_name)).size || 0,
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-gradient-to-r from-[hsl(var(--teacher-primary))] to-[hsl(var(--teacher-dark))] text-white shadow-md">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <BookOpen className="w-8 h-8" />
                Teacher Dashboard
              </h1>
              <p className="text-white/90 mt-1">
                Welcome back, {teacherData?.profiles?.full_name}!
              </p>
            </div>
            <Button variant="secondary" onClick={signOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-[hsl(var(--teacher-primary))] to-[hsl(var(--teacher-dark))] text-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                My Subjects
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{stats.subjects}</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[hsl(var(--admin-primary))] to-[hsl(var(--admin-dark))] text-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <Users className="w-5 h-5" />
                Classes
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{stats.classes}</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[hsl(var(--student-primary))] to-[hsl(var(--student-dark))] text-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Today's Schedule
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">5</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="subjects" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-2">
            <TabsTrigger value="subjects">My Subjects</TabsTrigger>
            <TabsTrigger value="grades">Manage Grades</TabsTrigger>
          </TabsList>

          <TabsContent value="subjects">
            {loading ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">Loading...</p>
                </CardContent>
              </Card>
            ) : teacherData?.id ? (
              <SubjectClasses teacherId={teacherData.id} />
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">Teacher profile not found</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          <TabsContent value="grades">
            {loading ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">Loading...</p>
                </CardContent>
              </Card>
            ) : teacherData?.id ? (
              <GradeManagement teacherId={teacherData.id} />
            ) : (
              <Card>
                <CardContent className="py-8 text-center">
                  <p className="text-muted-foreground">Teacher profile not found</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default TeacherDashboard;
