import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/components/auth/AuthProvider';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { GraduationCap, Calendar, BookOpen, LogOut, ClipboardList } from 'lucide-react';
import AttendanceView from '@/components/student/AttendanceView';
import GradesView from '@/components/student/GradesView';
import TimetableView from '@/components/student/TimetableView';

const StudentDashboard = () => {
  const { signOut, user } = useAuth();
  const [studentData, setStudentData] = useState<any>(null);
  const [stats, setStats] = useState({
    attendance: 0,
    avgGrade: 'N/A',
    totalSubjects: 0,
  });

  useEffect(() => {
    if (user) {
      loadStudentData();
    }
  }, [user]);

  const loadStudentData = async () => {
    if (!user) return;

    const { data: student } = await supabase
      .from('students')
      .select('*, profiles(full_name)')
      .eq('user_id', user.id)
      .single();

    if (student) {
      setStudentData(student);

      // Calculate attendance percentage
      const { data: attendance } = await supabase
        .from('attendance')
        .select('status')
        .eq('student_id', student.id);

      if (attendance && attendance.length > 0) {
        const present = attendance.filter((a) => a.status === 'present').length;
        const percentage = Math.round((present / attendance.length) * 100);
        setStats((prev) => ({ ...prev, attendance: percentage }));
      }

      // Get total subjects
      const { data: subjects } = await supabase
        .from('subjects')
        .select('id');

      setStats((prev) => ({ ...prev, totalSubjects: subjects?.length || 0 }));
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-gradient-to-r from-[hsl(var(--student-primary))] to-[hsl(var(--student-dark))] text-white shadow-md">
        <div className="container mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold flex items-center gap-2">
                <GraduationCap className="w-8 h-8" />
                Student Dashboard
              </h1>
              <p className="text-white/90 mt-1">
                Welcome, {studentData?.profiles?.full_name}! • {studentData?.class_name}
              </p>
            </div>
            <Button variant="secondary" onClick={signOut}>
              <LogOut className="w-4 h-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-[hsl(var(--student-primary))] to-[hsl(var(--student-dark))] text-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <Calendar className="w-5 h-5" />
                Attendance
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{stats.attendance}%</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[hsl(var(--admin-primary))] to-[hsl(var(--admin-dark))] text-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <ClipboardList className="w-5 h-5" />
                Average Grade
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{stats.avgGrade}</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-[hsl(var(--teacher-primary))] to-[hsl(var(--teacher-dark))] text-white">
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-medium flex items-center gap-2">
                <BookOpen className="w-5 h-5" />
                Total Subjects
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-4xl font-bold">{stats.totalSubjects}</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="grades" className="space-y-6">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="grades">Grades</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="timetable">Timetable</TabsTrigger>
          </TabsList>

          <TabsContent value="grades">
            <GradesView studentId={studentData?.id} />
          </TabsContent>

          <TabsContent value="attendance">
            <AttendanceView studentId={studentData?.id} />
          </TabsContent>

          <TabsContent value="timetable">
            <TimetableView className={studentData?.class_name} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default StudentDashboard;
