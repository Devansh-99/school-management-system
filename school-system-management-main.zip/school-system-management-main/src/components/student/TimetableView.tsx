import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';

interface TimetableEntry {
  id: string;
  day_of_week: string;
  start_time: string;
  end_time: string;
  subjects: {
    name: string;
  };
  teachers: {
    profiles: {
      full_name: string;
    };
  };
}

const TimetableView = ({ className }: { className: string | undefined }) => {
  const [timetable, setTimetable] = useState<Record<string, TimetableEntry[]>>({});

  useEffect(() => {
    if (className) {
      loadTimetable();
    }
  }, [className]);

  const loadTimetable = async () => {
    if (!className) return;

    const { data } = await supabase
      .from('timetable')
      .select('*, subjects(name), teachers(profiles(full_name))')
      .eq('class_name', className)
      .order('start_time');

    if (data) {
      const grouped = data.reduce((acc, entry) => {
        if (!acc[entry.day_of_week]) {
          acc[entry.day_of_week] = [];
        }
        acc[entry.day_of_week].push(entry);
        return acc;
      }, {} as Record<string, TimetableEntry[]>);

      setTimetable(grouped);
    }
  };

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

  return (
    <Card>
      <CardHeader>
        <CardTitle>Weekly Timetable</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {days.map((day) => (
            <div key={day}>
              <h3 className="text-lg font-semibold mb-3 text-primary">{day}</h3>
              <div className="grid gap-3">
                {timetable[day]?.map((entry) => (
                  <div
                    key={entry.id}
                    className="flex items-center justify-between p-4 border rounded-lg bg-card hover:shadow-md transition-shadow"
                  >
                    <div className="flex-1">
                      <h4 className="font-semibold">{entry.subjects.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {entry.teachers.profiles.full_name}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">
                        {entry.start_time} - {entry.end_time}
                      </p>
                    </div>
                  </div>
                ))}
                {(!timetable[day] || timetable[day].length === 0) && (
                  <p className="text-muted-foreground text-center py-4">No classes scheduled</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};

export default TimetableView;
