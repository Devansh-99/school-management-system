import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';

interface Attendance {
  id: string;
  date: string;
  status: string;
}

const AttendanceView = ({ studentId }: { studentId: string | undefined }) => {
  const [attendance, setAttendance] = useState<Attendance[]>([]);

  useEffect(() => {
    if (studentId) {
      loadAttendance();
    }
  }, [studentId]);

  const loadAttendance = async () => {
    if (!studentId) return;

    const { data } = await supabase
      .from('attendance')
      .select('*')
      .eq('student_id', studentId)
      .order('date', { ascending: false })
      .limit(30);

    setAttendance(data || []);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'present':
        return 'bg-[hsl(var(--student-primary))] text-white';
      case 'absent':
        return 'bg-destructive text-white';
      case 'late':
        return 'bg-amber-500 text-white';
      default:
        return 'bg-muted';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Attendance Record (Last 30 Days)</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
          {attendance.map((record) => (
            <div key={record.id} className="flex flex-col items-center p-3 border rounded-lg">
              <p className="text-sm font-medium mb-2">
                {format(new Date(record.date), 'MMM dd, yyyy')}
              </p>
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold capitalize ${getStatusColor(
                  record.status
                )}`}
              >
                {record.status}
              </span>
            </div>
          ))}
          {attendance.length === 0 && (
            <p className="text-muted-foreground col-span-full text-center py-8">
              No attendance records yet
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default AttendanceView;
