import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface Grade {
  id: string;
  grade: string;
  term: string;
  comments: string;
  subjects: {
    name: string;
  };
}

const GradesView = ({ studentId }: { studentId: string | undefined }) => {
  const [grades, setGrades] = useState<Grade[]>([]);

  useEffect(() => {
    if (studentId) {
      loadGrades();
    }
  }, [studentId]);

  const loadGrades = async () => {
    if (!studentId) return;

    const { data } = await supabase
      .from('grades')
      .select('*, subjects(name)')
      .eq('student_id', studentId)
      .order('term');

    setGrades(data || []);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>My Grades</CardTitle>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Subject</TableHead>
              <TableHead>Term</TableHead>
              <TableHead>Grade</TableHead>
              <TableHead>Comments</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {grades.map((grade) => (
              <TableRow key={grade.id}>
                <TableCell className="font-medium">{grade.subjects.name}</TableCell>
                <TableCell>{grade.term}</TableCell>
                <TableCell>
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-[hsl(var(--student-light))] text-[hsl(var(--student-dark))]">
                    {grade.grade}
                  </span>
                </TableCell>
                <TableCell className="text-muted-foreground">{grade.comments || '-'}</TableCell>
              </TableRow>
            ))}
            {grades.length === 0 && (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                  No grades available yet
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default GradesView;
