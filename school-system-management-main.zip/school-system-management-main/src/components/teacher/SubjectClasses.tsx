import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { BookOpen, Plus } from 'lucide-react';
import { toast } from 'sonner';

interface SubjectClass {
  id: string;
  class_name: string;
  subjects: {
    name: string;
  };
}

interface Subject {
  id: string;
  name: string;
}

const SubjectClasses = ({ teacherId }: { teacherId: string | undefined }) => {
  const [subjectClasses, setSubjectClasses] = useState<SubjectClass[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [formData, setFormData] = useState({
    subject_name: '',
    class_name: '',
    day_of_week: '',
    start_time: '',
    end_time: '',
  });

  useEffect(() => {
    if (teacherId) {
      loadSubjectClasses();
    }
    loadSubjects();
  }, [teacherId]);

  const loadSubjectClasses = async () => {
    if (!teacherId) return;

    const { data } = await supabase
      .from('teacher_subjects')
      .select('*, subjects(name)')
      .eq('teacher_id', teacherId);

    setSubjectClasses(data || []);
  };

  const loadSubjects = async () => {
    const { data } = await supabase.from('subjects').select('id, name');
    setSubjects(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!teacherId) {
      toast.error('Teacher ID not found');
      return;
    }

    try {
      // First, check if subject exists or create it
      let subjectId: string;
      const { data: existingSubject } = await supabase
        .from('subjects')
        .select('id')
        .eq('name', formData.subject_name.trim())
        .single();

      if (existingSubject) {
        subjectId = existingSubject.id;
      } else {
        const { data: newSubject, error: subjectError } = await supabase
          .from('subjects')
          .insert({ name: formData.subject_name.trim() })
          .select('id')
          .single();

        if (subjectError) throw subjectError;
        subjectId = newSubject.id;
      }

      // Then, create teacher_subject entry
      const { error: teacherSubjectError } = await supabase
        .from('teacher_subjects')
        .insert({
          teacher_id: teacherId,
          subject_id: subjectId,
          class_name: formData.class_name,
        });

      if (teacherSubjectError) throw teacherSubjectError;

      // Finally, create timetable entry
      const { error: timetableError } = await supabase
        .from('timetable')
        .insert({
          teacher_id: teacherId,
          subject_id: subjectId,
          class_name: formData.class_name,
          day_of_week: formData.day_of_week,
          start_time: formData.start_time,
          end_time: formData.end_time,
        });

      if (timetableError) throw timetableError;

      toast.success('Subject added successfully');
      setIsDialogOpen(false);
      setFormData({
        subject_name: '',
        class_name: '',
        day_of_week: '',
        start_time: '',
        end_time: '',
      });
      loadSubjectClasses();
    } catch (error: any) {
      toast.error(error.message || 'Failed to add subject');
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>My Subject Classes</CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button className="bg-gradient-to-r from-[hsl(var(--teacher-primary))] to-[hsl(var(--teacher-dark))] text-white">
                <Plus className="w-4 h-4 mr-2" />
                Add Subject
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Add New Subject</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <Label htmlFor="subject_name">Subject</Label>
                  <Input
                    id="subject_name"
                    value={formData.subject_name}
                    onChange={(e) => setFormData({ ...formData, subject_name: e.target.value })}
                    placeholder="e.g., Mathematics"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="class_name">Class Name</Label>
                  <Input
                    id="class_name"
                    value={formData.class_name}
                    onChange={(e) => setFormData({ ...formData, class_name: e.target.value })}
                    placeholder="e.g., Class 10"
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="day_of_week">Day of Week</Label>
                  <Select
                    value={formData.day_of_week}
                    onValueChange={(value) => setFormData({ ...formData, day_of_week: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select day" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Monday">Monday</SelectItem>
                      <SelectItem value="Tuesday">Tuesday</SelectItem>
                      <SelectItem value="Wednesday">Wednesday</SelectItem>
                      <SelectItem value="Thursday">Thursday</SelectItem>
                      <SelectItem value="Friday">Friday</SelectItem>
                      <SelectItem value="Saturday">Saturday</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="start_time">Start Time</Label>
                    <Input
                      id="start_time"
                      type="time"
                      value={formData.start_time}
                      onChange={(e) => setFormData({ ...formData, start_time: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="end_time">End Time</Label>
                    <Input
                      id="end_time"
                      type="time"
                      value={formData.end_time}
                      onChange={(e) => setFormData({ ...formData, end_time: e.target.value })}
                      required
                    />
                  </div>
                </div>
                <Button type="submit" className="w-full">
                  Add Subject
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {subjectClasses.map((sc) => (
            <Card
              key={sc.id}
              className="bg-gradient-to-br from-[hsl(var(--teacher-light))] to-white hover:shadow-md transition-shadow"
            >
              <CardContent className="p-6">
                <div className="flex items-start gap-3">
                  <div className="p-2 bg-[hsl(var(--teacher-primary))]/10 rounded-lg">
                    <BookOpen className="w-5 h-5 text-[hsl(var(--teacher-primary))]" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-lg">{sc.subjects.name}</h3>
                    <p className="text-sm text-muted-foreground">{sc.class_name}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
          {subjectClasses.length === 0 && (
            <p className="text-muted-foreground col-span-full text-center py-8">
              No subjects assigned yet
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};

export default SubjectClasses;
