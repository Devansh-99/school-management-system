import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Save } from 'lucide-react';
import { toast } from 'sonner';

interface Student {
  id: string;
  roll_number: string;
  profiles: {
    full_name: string;
  };
}

const GradeManagement = ({ teacherId }: { teacherId: string | undefined }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<any[]>([]);
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedTerm, setSelectedTerm] = useState('Term 1');
  const [grades, setGrades] = useState<Record<string, { grade: string; comments: string }>>({});

  useEffect(() => {
    if (teacherId) {
      loadSubjects();
    }
  }, [teacherId]);

  useEffect(() => {
    if (selectedSubject) {
      loadStudentsAndGrades();
    }
  }, [selectedSubject, selectedTerm]);

  const loadSubjects = async () => {
    if (!teacherId) return;

    const { data } = await supabase
      .from('teacher_subjects')
      .select('subject_id, subjects(id, name)')
      .eq('teacher_id', teacherId);

    setSubjects(data || []);
    if (data && data.length > 0) {
      setSelectedSubject(data[0].subjects.id);
    }
  };

  const loadStudentsAndGrades = async () => {
    if (!selectedSubject) return;

    // Get all students
    const { data: studentsData } = await supabase
      .from('students')
      .select('id, roll_number, profiles(full_name)')
      .order('roll_number');

    setStudents(studentsData || []);

    // Get existing grades
    if (studentsData) {
      const { data: gradesData } = await supabase
        .from('grades')
        .select('*')
        .eq('subject_id', selectedSubject)
        .eq('term', selectedTerm)
        .in('student_id', studentsData.map(s => s.id));

      const gradesMap: Record<string, { grade: string; comments: string }> = {};
      gradesData?.forEach((g) => {
        gradesMap[g.student_id] = { grade: g.grade, comments: g.comments || '' };
      });
      setGrades(gradesMap);
    }
  };

  const handleGradeChange = (studentId: string, field: 'grade' | 'comments', value: string) => {
    setGrades((prev) => ({
      ...prev,
      [studentId]: {
        ...prev[studentId],
        [field]: value,
      },
    }));
  };

  const handleSaveGrade = async (studentId: string) => {
    if (!teacherId || !selectedSubject) return;

    const gradeData = grades[studentId];
    if (!gradeData || !gradeData.grade) {
      toast.error('Please enter a grade');
      return;
    }

    try {
      const { error } = await supabase.from('grades').upsert({
        student_id: studentId,
        subject_id: selectedSubject,
        teacher_id: teacherId,
        term: selectedTerm,
        grade: gradeData.grade,
        comments: gradeData.comments,
      });

      if (error) throw error;
      toast.success('Grade saved successfully');
    } catch (error: any) {
      toast.error(error.message || 'Failed to save grade');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Manage Student Grades</CardTitle>
        <div className="flex gap-4 mt-4">
          <Select value={selectedSubject} onValueChange={setSelectedSubject}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Select subject" />
            </SelectTrigger>
            <SelectContent>
              {subjects.map((s) => (
                <SelectItem key={s.subjects.id} value={s.subjects.id}>
                  {s.subjects.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={selectedTerm} onValueChange={setSelectedTerm}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Term 1">Term 1</SelectItem>
              <SelectItem value="Term 2">Term 2</SelectItem>
              <SelectItem value="Term 3">Term 3</SelectItem>
              <SelectItem value="Final">Final</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Roll No</TableHead>
              <TableHead>Student Name</TableHead>
              <TableHead>Grade</TableHead>
              <TableHead>Comments</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {students.map((student) => (
              <TableRow key={student.id}>
                <TableCell>{student.roll_number}</TableCell>
                <TableCell>{student.profiles.full_name}</TableCell>
                <TableCell>
                  <Input
                    value={grades[student.id]?.grade || ''}
                    onChange={(e) => handleGradeChange(student.id, 'grade', e.target.value)}
                    placeholder="A, B+, etc."
                    className="w-24"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    value={grades[student.id]?.comments || ''}
                    onChange={(e) => handleGradeChange(student.id, 'comments', e.target.value)}
                    placeholder="Optional comments"
                    className="w-48"
                  />
                </TableCell>
                <TableCell>
                  <Button size="sm" onClick={() => handleSaveGrade(student.id)}>
                    <Save className="w-4 h-4 mr-1" />
                    Save
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default GradeManagement;
