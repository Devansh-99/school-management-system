import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Plus, Edit, Trash2, Search } from 'lucide-react';
import { toast } from 'sonner';

interface Teacher {
  id: string;
  qualification: string;
  profiles: {
    full_name: string;
    email: string;
    phone: string;
  };
}

const TeacherManagement = ({ onUpdate }: { onUpdate: () => void }) => {
  const [teachers, setTeachers] = useState<Teacher[]>([]);
  const [filteredTeachers, setFilteredTeachers] = useState<Teacher[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<Teacher | null>(null);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    phone: '',
    qualification: '',
  });

  useEffect(() => {
    loadTeachers();
  }, []);

  useEffect(() => {
    const filtered = teachers.filter(
      (t) =>
        t.profiles.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        t.profiles.email.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredTeachers(filtered);
  }, [searchTerm, teachers]);

  const loadTeachers = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Not authenticated');
        return;
      }

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-teachers`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ method: 'GET_ALL' }),
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error);
      
      setTeachers(result.data || []);
      setFilteredTeachers(result.data || []);
    } catch (error: any) {
      toast.error('Failed to load teachers');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const isEditing = editingTeacher !== null;
      const method = isEditing ? 'UPDATE' : 'CREATE';

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-teachers`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          method,
          data: isEditing ? {
            id: editingTeacher.id,
            full_name: formData.full_name,
            qualification: formData.qualification,
            phone: formData.phone,
          } : {
            email: formData.email,
            password: Math.random().toString(36).slice(-8),
            full_name: formData.full_name,
            qualification: formData.qualification,
            phone: formData.phone,
          },
        }),
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error);

      toast.success(`Teacher ${isEditing ? 'updated' : 'added'} successfully`);
      setIsDialogOpen(false);
      setEditingTeacher(null);
      setFormData({
        full_name: '',
        email: '',
        phone: '',
        qualification: '',
      });
      loadTeachers();
      onUpdate();
    } catch (error: any) {
      toast.error(error.message || `Failed to ${editingTeacher ? 'update' : 'add'} teacher`);
    }
  };

  const handleEdit = (teacher: Teacher) => {
    setEditingTeacher(teacher);
    setFormData({
      full_name: teacher.profiles.full_name,
      email: teacher.profiles.email,
      phone: teacher.profiles.phone,
      qualification: teacher.qualification,
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingTeacher(null);
    setFormData({
      full_name: '',
      email: '',
      phone: '',
      qualification: '',
    });
  };

  const handleOpenAddDialog = () => {
    setEditingTeacher(null);
    setFormData({
      full_name: '',
      email: '',
      phone: '',
      qualification: '',
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this teacher?')) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-teachers`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ method: 'DELETE', data: { id } }),
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error);

      toast.success('Teacher deleted successfully');
      loadTeachers();
      onUpdate();
    } catch (error: any) {
      toast.error('Failed to delete teacher');
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Teacher Management</CardTitle>
          <div className="flex gap-3">
            <div className="relative w-64">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search teachers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              if (!open) handleCloseDialog();
            }}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-gradient-to-r from-[hsl(var(--teacher-primary))] to-[hsl(var(--teacher-dark))] text-white"
                  onClick={handleOpenAddDialog}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Teacher
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingTeacher ? 'Edit Teacher' : 'Add New Teacher'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="full_name">Full Name</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      required
                    />
                  </div>
                  {!editingTeacher && (
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                      />
                    </div>
                  )}
                  <div>
                    <Label htmlFor="phone">Phone</Label>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="qualification">Qualification</Label>
                    <Input
                      id="qualification"
                      value={formData.qualification}
                      onChange={(e) => setFormData({ ...formData, qualification: e.target.value })}
                      required
                    />
                  </div>
                  <Button type="submit" className="w-full">
                    {editingTeacher ? 'Update Teacher' : 'Add Teacher'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Qualification</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredTeachers.map((teacher) => (
              <TableRow key={teacher.id}>
                <TableCell>{teacher.profiles.full_name}</TableCell>
                <TableCell>{teacher.profiles.email}</TableCell>
                <TableCell>{teacher.profiles.phone}</TableCell>
                <TableCell>{teacher.qualification}</TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(teacher)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(teacher.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default TeacherManagement;
