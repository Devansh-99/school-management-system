import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Edit, Trash2, Search } from 'lucide-react';
import { toast } from 'sonner';

interface Student {
  id: string;
  roll_number: string;
  parent_name: string;
  parent_phone: string;
  class_name: string;
  profiles: {
    full_name: string;
    email: string;
  };
}

const StudentManagement = ({ onUpdate }: { onUpdate: () => void }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [filteredStudents, setFilteredStudents] = useState<Student[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    roll_number: '',
    parent_name: '',
    parent_phone: '',
    class_name: 'Class 1',
  });

  useEffect(() => {
    loadStudents();
  }, []);

  useEffect(() => {
    const filtered = students.filter(
      (s) =>
        s.profiles.full_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.roll_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
        s.class_name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredStudents(filtered);
  }, [searchTerm, students]);

  const loadStudents = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        toast.error('Not authenticated');
        return;
      }

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-students`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ method: 'GET_ALL' }),
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error);
      
      setStudents(result.data || []);
      setFilteredStudents(result.data || []);
    } catch (error: any) {
      toast.error('Failed to load students');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const isEditing = editingStudent !== null;
      const method = isEditing ? 'UPDATE' : 'CREATE';

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-students`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          method,
          data: isEditing ? {
            id: editingStudent.id,
            full_name: formData.full_name,
            roll_number: formData.roll_number,
            class_name: formData.class_name,
            parent_name: formData.parent_name,
            parent_phone: formData.parent_phone,
          } : {
            email: formData.email,
            password: Math.random().toString(36).slice(-8),
            full_name: formData.full_name,
            roll_number: formData.roll_number,
            class_name: formData.class_name,
            parent_name: formData.parent_name,
            parent_phone: formData.parent_phone,
          },
        }),
      });

      const result = await response.json();
      if (!response.ok) {
        if (response.status === 409) {
          toast.error('A student with this email already exists');
        } else if (response.status === 422) {
          toast.error('Unable to create student. Please check the email and try again.');
        } else {
          toast.error(result.error || `Failed to ${isEditing ? 'update' : 'add'} student`);
        }
        return;
      }

      toast.success(`Student ${isEditing ? 'updated' : 'added'} successfully`);
      setIsDialogOpen(false);
      setEditingStudent(null);
      setFormData({
        full_name: '',
        email: '',
        roll_number: '',
        parent_name: '',
        parent_phone: '',
        class_name: 'Class 1',
      });
      loadStudents();
      onUpdate();
    } catch (error: any) {
      toast.error(error.message || `Failed to ${editingStudent ? 'update' : 'add'} student`);
    }
  };

  const handleEdit = (student: Student) => {
    setEditingStudent(student);
    setFormData({
      full_name: student.profiles.full_name,
      email: student.profiles.email,
      roll_number: student.roll_number,
      parent_name: student.parent_name,
      parent_phone: student.parent_phone,
      class_name: student.class_name,
    });
    setIsDialogOpen(true);
  };

  const handleCloseDialog = () => {
    setIsDialogOpen(false);
    setEditingStudent(null);
    setFormData({
      full_name: '',
      email: '',
      roll_number: '',
      parent_name: '',
      parent_phone: '',
      class_name: 'Class 1',
    });
  };

  const handleOpenAddDialog = () => {
    setEditingStudent(null);
    setFormData({
      full_name: '',
      email: '',
      roll_number: '',
      parent_name: '',
      parent_phone: '',
      class_name: 'Class 1',
    });
    setIsDialogOpen(true);
  };

  const handleDelete = async (id: string, userId: string) => {
    if (!confirm('Are you sure you want to delete this student?')) return;

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) throw new Error('Not authenticated');

      const response = await fetch(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/admin-students`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ method: 'DELETE', data: { id } }),
      });

      const result = await response.json();
      if (!response.ok) throw new Error(result.error);

      toast.success('Student deleted successfully');
      loadStudents();
      onUpdate();
    } catch (error: any) {
      toast.error('Failed to delete student');
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Student Management</CardTitle>
          <div className="flex gap-3">
            <div className="relative w-64">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search students..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Dialog open={isDialogOpen} onOpenChange={(open) => {
              if (!open) handleCloseDialog();
            }}>
              <DialogTrigger asChild>
                <Button 
                  className="bg-gradient-to-r from-[hsl(var(--student-primary))] to-[hsl(var(--student-dark))] text-white"
                  onClick={handleOpenAddDialog}
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Add Student
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editingStudent ? 'Edit Student' : 'Add New Student'}</DialogTitle>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <Label htmlFor="full_name">Full Name</Label>
                    <Input
                      id="full_name"
                      value={formData.full_name}
                      onChange={(e) => setFormData({ ...formData, full_name: e.target.value })}
                      required
                    />
                  </div>
                  {!editingStudent && (
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        required
                      />
                    </div>
                  )}
                  <div>
                    <Label htmlFor="roll_number">Roll Number</Label>
                    <Input
                      id="roll_number"
                      value={formData.roll_number}
                      onChange={(e) => setFormData({ ...formData, roll_number: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="parent_name">Parent Name</Label>
                    <Input
                      id="parent_name"
                      value={formData.parent_name}
                      onChange={(e) => setFormData({ ...formData, parent_name: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="parent_phone">Parent Phone</Label>
                    <Input
                      id="parent_phone"
                      type="tel"
                      value={formData.parent_phone}
                      onChange={(e) => setFormData({ ...formData, parent_phone: e.target.value })}
                      required
                    />
                  </div>
                  <div>
                    <Label htmlFor="class_name">Class</Label>
                    <Select
                      value={formData.class_name}
                      onValueChange={(value) => setFormData({ ...formData, class_name: value })}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {Array.from({ length: 10 }, (_, i) => i + 1).map((num) => (
                          <SelectItem key={num} value={`Class ${num}`}>
                            Class {num}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <Button type="submit" className="w-full">
                    {editingStudent ? 'Update Student' : 'Add Student'}
                  </Button>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Roll No</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Parent</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Class</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredStudents.map((student) => (
              <TableRow key={student.id}>
                <TableCell>{student.roll_number}</TableCell>
                <TableCell>{student.profiles.full_name}</TableCell>
                <TableCell>{student.parent_name}</TableCell>
                <TableCell>{student.parent_phone}</TableCell>
                <TableCell>{student.class_name}</TableCell>
                <TableCell>
                  <div className="flex gap-2">
                    <Button size="sm" variant="outline" onClick={() => handleEdit(student)}>
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="destructive"
                      onClick={() => handleDelete(student.id, student.profiles.email)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
};

export default StudentManagement;
