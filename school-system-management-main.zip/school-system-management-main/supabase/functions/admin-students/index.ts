import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? '',
      {
        global: {
          headers: { Authorization: req.headers.get('Authorization')! },
        },
      }
    );

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    );

    // Verify user is admin
    const { data: { user } } = await supabaseClient.auth.getUser();
    if (!user) {
      return new Response(JSON.stringify({ error: 'Unauthorized' }), {
        status: 401,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { data: profile } = await supabaseAdmin
      .from('profiles')
      .select('role')
      .eq('id', user.id)
      .single();

    if (!profile || profile.role !== 'admin') {
      return new Response(JSON.stringify({ error: 'Forbidden - Admin access required' }), {
        status: 403,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      });
    }

    const { method, data } = await req.json();

    // Handle different operations
    switch (method) {
      case 'GET_ALL': {
        const { data: students, error } = await supabaseAdmin
          .from('students')
          .select(`
            *,
            profiles:user_id (
              email,
              full_name,
              phone
            )
          `)
          .order('created_at', { ascending: false });

        if (error) throw error;
        return new Response(JSON.stringify({ data: students }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'CREATE': {
        const { email, password, full_name, roll_number, class_name, parent_name, parent_phone } = data;

        // If a user with this email already exists, link them instead of failing
        const { data: existingProfile } = await supabaseAdmin
          .from('profiles')
          .select('id')
          .eq('email', email)
          .maybeSingle();

        if (existingProfile?.id) {
          // Prevent duplicate student records for the same user
          const { data: existingStudent } = await supabaseAdmin
            .from('students')
            .select('id')
            .eq('user_id', existingProfile.id)
            .maybeSingle();

          if (existingStudent?.id) {
            return new Response(JSON.stringify({ error: 'Student already exists for this email' }), {
              status: 409,
              headers: { ...corsHeaders, 'Content-Type': 'application/json' },
            });
          }

          // Optionally update profile's full name if provided
          if (full_name) {
            await supabaseAdmin
              .from('profiles')
              .update({ full_name })
              .eq('id', existingProfile.id);
          }

          // Create student record linked to the existing user
          const { data: student, error: studentError } = await supabaseAdmin
            .from('students')
            .insert({
              user_id: existingProfile.id,
              roll_number,
              class_name,
              parent_name,
              parent_phone,
            })
            .select()
            .single();

          if (studentError) throw studentError;

          return new Response(JSON.stringify({ data: student }), {
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Create auth user when none exists
        const { data: authUser, error: authError } = await supabaseAdmin.auth.admin.createUser({
          email,
          password,
          email_confirm: true,
          user_metadata: {
            full_name,
            role: 'student',
          },
        });

        if (authError) {
          // If user already exists but profile doesn't (rare case), fetch the auth user
          if (authError.message.includes('already been registered')) {
            const { data: { users } } = await supabaseAdmin.auth.admin.listUsers();
            const existingAuthUser = users.find(u => u.email === email);
            
            if (existingAuthUser) {
              // Check if student already exists
              const { data: existingStudent } = await supabaseAdmin
                .from('students')
                .select('id')
                .eq('user_id', existingAuthUser.id)
                .maybeSingle();

              if (existingStudent?.id) {
                return new Response(JSON.stringify({ error: 'Student already exists for this email' }), {
                  status: 409,
                  headers: { ...corsHeaders, 'Content-Type': 'application/json' },
                });
              }

              // Create student record for existing auth user
              const { data: student, error: studentError } = await supabaseAdmin
                .from('students')
                .insert({
                  user_id: existingAuthUser.id,
                  roll_number,
                  class_name,
                  parent_name,
                  parent_phone,
                })
                .select()
                .single();

              if (studentError) throw studentError;

              return new Response(JSON.stringify({ data: student }), {
                headers: { ...corsHeaders, 'Content-Type': 'application/json' },
              });
            }
          }
          
          return new Response(JSON.stringify({ error: authError.message }), {
            status: 422,
            headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          });
        }

        // Create student record
        const { data: student, error: studentError } = await supabaseAdmin
          .from('students')
          .insert({
            user_id: authUser.user.id,
            roll_number,
            class_name,
            parent_name,
            parent_phone,
          })
          .select()
          .single();

        if (studentError) throw studentError;

        return new Response(JSON.stringify({ data: student }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'UPDATE': {
        const { id, full_name, roll_number, class_name, parent_name, parent_phone, phone } = data;

        // Update student record
        const { data: student, error: studentError } = await supabaseAdmin
          .from('students')
          .update({
            roll_number,
            class_name,
            parent_name,
            parent_phone,
          })
          .eq('id', id)
          .select()
          .single();

        if (studentError) throw studentError;

        // Update profile
        if (student.user_id) {
          await supabaseAdmin
            .from('profiles')
            .update({ full_name, phone })
            .eq('id', student.user_id);
        }

        return new Response(JSON.stringify({ data: student }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      case 'DELETE': {
        const { id } = data;

        // Get student to find user_id
        const { data: student } = await supabaseAdmin
          .from('students')
          .select('user_id')
          .eq('id', id)
          .single();

        // Delete student record (will cascade to auth user via trigger)
        const { error: deleteError } = await supabaseAdmin
          .from('students')
          .delete()
          .eq('id', id);

        if (deleteError) throw deleteError;

        // Delete auth user
        if (student?.user_id) {
          await supabaseAdmin.auth.admin.deleteUser(student.user_id);
        }

        return new Response(JSON.stringify({ success: true }), {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
      }

      default:
        return new Response(JSON.stringify({ error: 'Invalid method' }), {
          status: 400,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        });
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    return new Response(JSON.stringify({ error: message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
